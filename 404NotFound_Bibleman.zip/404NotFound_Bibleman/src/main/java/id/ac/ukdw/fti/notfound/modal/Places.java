package id.ac.ukdw.fti.notfound.modal;

public class Places {
    private String tempat;
}
